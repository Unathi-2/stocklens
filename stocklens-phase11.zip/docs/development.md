
## Forecast evaluation with machine learning models

```bash
cd backend
pip install -r requirements-ml.txt          # scikit-learn and CPU PyTorch, a few hundred MB
python -m app.scripts.evaluate --symbols NPN AAPL --ml
```
Without `--ml` only the six GARCH family models are evaluated. With it each stock takes about a minute on two CPU cores.
