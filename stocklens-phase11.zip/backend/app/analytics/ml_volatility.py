"""Machine learning and deep learning one day ahead variance forecasts.

Pure functions. No web or database code belongs here. Plugs into the rolling scheme of
`app.analytics.evaluation`: the same estimation window, the same re-estimation dates, and forecasts that
use only information available before the forecast day.

Target and scale
- The target is the log of a realised variance proxy for the day. The proxy is the Parkinson range
  estimator, multiplied inside each estimation window by mean(r^2) / mean(proxy) so that it is on the same
  scale as the squared returns the GARCH models are judged against. Only that window is used for the scale.
- Models predict the log target. The forecast is exp(prediction) times Duan's smearing factor
  (the mean of exp(residual) on the training rows), which turns a geometric mean into a mean.

Models
- har:         HAR-RV (Corsi, 2009): OLS on the log proxy of yesterday, the last 5 days and the last 22 days.
- ridge:       ridge regression on the HAR terms plus extra lags, a leverage indicator and a return term.
- gbm:         gradient boosted shallow trees on the same features.
- lstm:        a small LSTM (8 units) over the last 22 days of the log proxy, a down day flag and the log squared
               return. The last 20 percent of each estimation window (in time order) chooses the stopping epoch and
               the smearing factor, and forecasts are kept inside the range of log targets seen in training.
- garch_lstm:  the same LSTM with the GJR-GARCH one day ahead log variance added before the output layer
               (a hybrid in the style of Kim and Won, 2018).
"""
import math

import numpy as np
import pandas as pd

SEED = 20241111
LSTM_STEPS = 22
MIN_ROWS = 100
FEATURE_COLUMNS = 8
HAR_COLUMNS = [0, 1, 2]

ML_MODELS: list[tuple[str, str]] = [
    ("har", "HAR-RV"),
    ("ridge", "Ridge regression"),
    ("gbm", "Gradient boosting"),
    ("lstm", "LSTM"),
    ("garch_lstm", "GARCH-LSTM"),
]
ML_NAMES = dict(ML_MODELS)


def availability() -> dict[str, bool]:
    """Which optional libraries are installed. scikit-learn is needed for ridge and boosting, torch for the LSTMs."""
    out = {}
    for name in ("sklearn", "torch"):
        try:
            __import__(name)
            out[name] = True
        except ImportError:
            out[name] = False
    return out


def usable_models(ids: list[str] | None = None) -> tuple[list[str], list[str]]:
    """Returns (models that can run, notes about models that cannot)."""
    have = availability()
    needs = {"har": None, "ridge": "sklearn", "gbm": "sklearn", "lstm": "torch", "garch_lstm": "torch"}
    wanted = ids or [m for m, _ in ML_MODELS]
    ok, notes = [], []
    for m in wanted:
        lib = needs[m]
        if lib is None or have[lib]:
            ok.append(m)
        else:
            notes.append(f"{ML_NAMES[m]} skipped: {lib} is not installed")
    return ok, notes


# ---------------------------------------------------------------- features


def scaled_proxy(raw_proxy: np.ndarray, returns: np.ndarray, window_slice: slice) -> np.ndarray:
    """Floor the proxy away from zero and put it on the scale of squared returns, using one window only."""
    raw = np.asarray(raw_proxy, dtype=float)
    win = raw[window_slice]
    r2 = np.asarray(returns, dtype=float)[window_slice] ** 2
    floor = 1e-3 * float(np.mean(win[win > 0])) if np.any(win > 0) else 1e-12
    raw = np.maximum(raw, floor)
    c = float(np.mean(r2) / np.mean(np.maximum(win, floor)))
    return raw * c


def build_features(rv: np.ndarray, r: np.ndarray) -> np.ndarray:
    """Feature matrix, one row per day t. Every feature for day t uses data up to day t-1 only.

    Columns: 0 log rv(t-1), 1 log mean rv(t-5..t-1), 2 log mean rv(t-22..t-1), 3 log rv(t-2), 4 log rv(t-3),
    5 down day flag (r(t-1) < 0), 6 flag times log rv(t-1), 7 log of squared return(t-1) plus a small constant.
    Rows before day 22 are NaN.
    """
    s = pd.Series(rv)
    lrv = np.log(rv)
    lag = lambda x, k: np.concatenate([np.full(k, np.nan), x[:-k]])  # noqa: E731
    mean5 = np.log(s.rolling(5).mean().shift(1).to_numpy())
    m22 = s.rolling(LSTM_STEPS).mean().shift(1).to_numpy()
    down = lag((r < 0).astype(float), 1)
    X = np.column_stack([
        lag(lrv, 1), mean5, np.log(m22), lag(lrv, 2), lag(lrv, 3), down, down * lag(lrv, 1),
        np.log(lag(r, 1) ** 2 + 0.01 * m22),
    ])
    X[:LSTM_STEPS] = np.nan
    return X


def _smear(residuals: np.ndarray) -> float:
    return float(np.mean(np.exp(np.clip(residuals, -5, 5))))


# ---------------------------------------------------------------- tabular models


def _fit_predict_tabular(model_id: str, X_tr, y_tr, X_te) -> np.ndarray:
    if model_id == "har":
        A = np.column_stack([np.ones(len(X_tr)), X_tr[:, HAR_COLUMNS]])
        beta, *_ = np.linalg.lstsq(A, y_tr, rcond=None)
        fit = A @ beta
        pred = np.column_stack([np.ones(len(X_te)), X_te[:, HAR_COLUMNS]]) @ beta
    elif model_id == "ridge":
        from sklearn.linear_model import RidgeCV
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler

        model = make_pipeline(StandardScaler(), RidgeCV(alphas=np.logspace(-2, 3, 12)))
        model.fit(X_tr, y_tr)
        fit, pred = model.predict(X_tr), model.predict(X_te)
    elif model_id == "gbm":
        from sklearn.ensemble import GradientBoostingRegressor

        model = GradientBoostingRegressor(
            n_estimators=150, max_depth=2, learning_rate=0.05, subsample=0.8, random_state=SEED
        )
        model.fit(X_tr, y_tr)
        fit, pred = model.predict(X_tr), model.predict(X_te)
    else:
        raise ValueError(model_id)
    return np.exp(pred) * _smear(y_tr - fit)


# ---------------------------------------------------------------- LSTM models

_LSTM_STATE: dict = {}  # warm start weights per model id, reset by reset_state()


def reset_state() -> None:
    _LSTM_STATE.clear()


def _sequences(U: np.ndarray, rows: np.ndarray) -> np.ndarray:
    """Inputs for target rows t: days t-22 .. t-1 of the per day inputs U (n by channels)."""
    return np.stack([U[t - LSTM_STEPS : t] for t in rows])


def _fit_predict_lstm(model_id: str, rv, r, g_log, tr_rows, te_rows, y) -> np.ndarray:
    """Train on tr_rows (full training on the first call, a short warm start afterwards), predict te_rows."""
    import torch
    from torch import nn

    torch.manual_seed(SEED)
    lrv = np.log(rv)
    down = (r < 0).astype(float)
    lr2 = np.log(r**2 + 0.01 * float(np.mean(rv[tr_rows])))  # constant from past days only
    U = np.column_stack([lrv, down, lr2])
    mu, sd = U[tr_rows[0] - LSTM_STEPS : tr_rows[-1]].mean(axis=0), U[tr_rows[0] - LSTM_STEPS : tr_rows[-1]].std(axis=0) + 1e-8
    U = (U - mu) / sd
    hybrid = model_id == "garch_lstm"
    if hybrid:
        gm, gs = g_log[tr_rows].mean(), g_log[tr_rows].std() + 1e-8
        G = ((g_log - gm) / gs).astype(np.float32)
    ym, ys = y[tr_rows].mean(), y[tr_rows].std() + 1e-8

    class Net(nn.Module):
        def __init__(self):
            super().__init__()
            self.lstm = nn.LSTM(U.shape[1], 8, batch_first=True)
            self.head = nn.Linear(8 + (1 if hybrid else 0), 1)

        def forward(self, x, g=None):
            out, _ = self.lstm(x)
            h = out[:, -1]
            if g is not None:
                h = torch.cat([h, g[:, None]], dim=1)
            return self.head(h).squeeze(1)

    net = Net()
    first = model_id not in _LSTM_STATE
    if not first:
        net.load_state_dict(_LSTM_STATE[model_id])
    max_epochs, patience = (80, 10) if first else (30, 6)
    opt = torch.optim.Adam(net.parameters(), lr=5e-3 if first else 2e-3, weight_decay=1e-3)

    Xall = torch.tensor(_sequences(U, tr_rows), dtype=torch.float32)
    yall = torch.tensor((y[tr_rows] - ym) / ys, dtype=torch.float32)
    gall = torch.tensor(G[tr_rows]) if hybrid else None
    cut = int(len(tr_rows) * 0.8)  # time ordered split: the last 20 percent of the window picks the stopping epoch
    g_fit = gall[:cut] if hybrid else None
    g_val = gall[cut:] if hybrid else None

    gen = torch.Generator().manual_seed(SEED)
    best_loss, best_state, since = math.inf, None, 0
    for _ in range(max_epochs):
        net.train()
        order = torch.randperm(cut, generator=gen)
        for i in range(0, cut, 64):
            b = order[i : i + 64]
            opt.zero_grad()
            nn.functional.mse_loss(net(Xall[b], g_fit[b] if hybrid else None), yall[b]).backward()
            opt.step()
        net.eval()
        with torch.no_grad():
            val_loss = float(nn.functional.mse_loss(net(Xall[cut:], g_val), yall[cut:]))
        if val_loss < best_loss - 1e-5:
            best_loss, since = val_loss, 0
            best_state = {k: v.clone() for k, v in net.state_dict().items()}
        else:
            since += 1
            if since >= patience:
                break
    net.load_state_dict(best_state)
    _LSTM_STATE[model_id] = best_state

    net.eval()
    with torch.no_grad():
        val_resid = (yall[cut:] - net(Xall[cut:], g_val)).numpy() * ys  # out of sample within the window
        Xte = torch.tensor(_sequences(U, te_rows), dtype=torch.float32)
        pred = net(Xte, torch.tensor(G[te_rows]) if hybrid else None).numpy() * ys + ym
    pred = np.clip(pred, y[tr_rows].min() - 0.5, y[tr_rows].max() + 0.5)  # keep forecasts inside the range seen in training
    return np.exp(pred) * _smear(val_resid)


# ---------------------------------------------------------------- one block


def forecast_block(
    model_ids: list[str],
    raw_proxy: np.ndarray,
    r: np.ndarray,
    s: int,
    e: int,
    window: int,
    garch_variance: np.ndarray | None,
) -> dict[str, np.ndarray]:
    """One day ahead variance forecasts for days s..e-1 using only data before each day.

    raw_proxy, r: the proxy and the returns for days 0..e-1 (the caller must not pass later days).
    The models are fitted on target days s-window .. s-1. garch_variance: GJR one day ahead variances for days 0..e-1
    under parameters estimated on the window, needed by garch_lstm.
    """
    rv = scaled_proxy(raw_proxy[:e], r[:e], slice(s - window, s))
    X = build_features(rv, r[:e])
    y = np.log(rv)
    first_row = max(s - window, LSTM_STEPS)
    tr_rows = np.arange(first_row, s)
    te_rows = np.arange(s, e)
    if len(tr_rows) < MIN_ROWS:
        raise ValueError("too few training rows")
    out: dict[str, np.ndarray] = {}
    for m in model_ids:
        if m in {"har", "ridge", "gbm"}:
            out[m] = _fit_predict_tabular(m, X[tr_rows], y[tr_rows], X[te_rows])
        else:
            g_log = np.log(garch_variance) if m == "garch_lstm" else None
            out[m] = _fit_predict_lstm(m, rv, r[:e], g_log, tr_rows, te_rows, y)
    for m, h in out.items():
        if not (np.all(np.isfinite(h)) and np.all(h > 0)):
            raise FloatingPointError(f"{m}: invalid forecast")
    return out
