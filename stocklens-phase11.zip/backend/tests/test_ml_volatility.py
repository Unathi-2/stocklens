import warnings

import numpy as np
import pandas as pd
import pytest

from app.analytics import evaluation as ev
from app.analytics import ml_volatility as ml
from test_volatility import gjr_returns


def make_series(n=900, seed=1):
    rng = np.random.default_rng(seed)
    r = gjr_returns(n, seed=seed)
    rv = (r**2 * 0.7 + 0.2 * pd.Series(r**2).rolling(10, min_periods=1).mean().to_numpy()) * np.exp(rng.normal(0, 0.1, n)) + 1e-4
    idx = pd.bdate_range("2021-01-04", periods=n)
    return pd.Series(r, index=idx), pd.Series(rv, index=idx)


def test_features_use_only_past_data():
    r, rv = make_series(400)
    X = ml.build_features(np.maximum(rv.to_numpy(), 1e-6), r.to_numpy())
    rv2, r2 = rv.to_numpy().copy(), r.to_numpy().copy()
    rv2[300:] *= 10
    r2[300:] *= 3
    X2 = ml.build_features(np.maximum(rv2, 1e-6), r2)
    assert np.allclose(X[:300], X2[:300], equal_nan=True)
    assert np.isnan(X[:22]).all() and np.isfinite(X[22:]).all()
    assert X.shape[1] == ml.FEATURE_COLUMNS


def test_scaled_proxy_matches_squared_returns_and_floors_zeros():
    r, rv = make_series(400)
    raw = rv.to_numpy().copy()
    raw[10] = 0.0
    out = ml.scaled_proxy(raw, r.to_numpy(), slice(100, 300))
    assert (out > 0).all()
    assert np.mean(out[100:300]) == pytest.approx(np.mean(r.to_numpy()[100:300] ** 2), rel=1e-9)


def test_har_beats_a_constant_forecast():
    r, rv = make_series(900)
    rvs = ml.scaled_proxy(rv.to_numpy(), r.to_numpy(), slice(100, 600))
    out = ml.forecast_block(["har"], rv.to_numpy(), r.to_numpy(), 600, 900, 500, None)["har"]
    assert len(out) == 300 and np.isfinite(out).all() and (out > 0).all()
    target = rvs[600:900]
    constant = np.full(300, rvs[100:600].mean())
    assert ev.qlike(target, out).mean() < ev.qlike(target, constant).mean()
    assert out.mean() == pytest.approx(target.mean(), rel=0.5)


def test_usable_models_reports_missing_libraries(monkeypatch):
    monkeypatch.setattr(ml, "availability", lambda: {"sklearn": True, "torch": False})
    ok, notes = ml.usable_models()
    assert ok == ["har", "ridge", "gbm"] and len(notes) == 2 and "torch" in notes[0]


def test_ml_models_in_rolling_harness_are_causal():
    pytest.importorskip("sklearn")
    r, rv = make_series(650, seed=4)
    kw = dict(window=300, refit_every=200, ml_models=["har", "ridge", "gbm"])
    a = ev.rolling_forecasts(r, rv=rv, **kw)
    r2, rv2 = r.copy(), rv.copy()
    r2.iloc[520:] *= 4.0
    rv2.iloc[520:] *= 10.0
    b = ev.rolling_forecasts(r2, rv=rv2, **kw)
    for m in ("har", "ridge", "gbm"):
        fa, fb = a["forecasts"][m], b["forecasts"][m]
        assert np.isfinite(fa).all() and (fa > 0).all(), m
        assert np.allclose(fa[:220], fb[:220], rtol=1e-8), m
    assert a["failures"]["har"] == 0


def test_lstm_models_run_and_are_deterministic():
    pytest.importorskip("torch")
    r, rv = make_series(650, seed=5)
    kw = dict(window=300, refit_every=350, ml_models=["lstm", "garch_lstm"])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        a = ev.rolling_forecasts(r, rv=rv, **kw)
        b = ev.rolling_forecasts(r, rv=rv, **kw)
    for m in ("lstm", "garch_lstm"):
        assert np.isfinite(a["forecasts"][m]).all() and (a["forecasts"][m] > 0).all(), m
        assert np.allclose(a["forecasts"][m], b["forecasts"][m], rtol=1e-4), m
        assert a["failures"][m] == 0


def test_lstm_forecasts_do_not_use_later_data():
    pytest.importorskip("torch")
    r, rv = make_series(650, seed=6)
    kw = dict(window=300, refit_every=200, ml_models=["lstm"])
    a = ev.rolling_forecasts(r, rv=rv, **kw)
    r2, rv2 = r.copy(), rv.copy()
    r2.iloc[520:] *= 4.0
    rv2.iloc[520:] *= 10.0
    b = ev.rolling_forecasts(r2, rv=rv2, **kw)
    assert np.allclose(a["forecasts"]["lstm"][:220], b["forecasts"]["lstm"][:220], rtol=1e-3)


def test_evaluate_handles_ml_ids_and_families():
    rng = np.random.default_rng(3)
    n = 300
    truth = 1 + 0.4 * np.sin(np.linspace(0, 9, n))
    proxy = truth * rng.chisquare(1, n)
    ids = ["sgarch", "gjr", "har", "lstm"]
    payload = {
        "dates": [str(d.date()) for d in pd.bdate_range("2023-01-02", periods=n)],
        "forecasts": {m: (truth * f).tolist() for m, f in zip(ids, (1.4, 1.0, 1.05, 0.7))},
        "proxies": {"squared_return": proxy.tolist(), "parkinson": proxy.tolist(), "garman_klass": proxy.tolist()},
        "failures": {}, "non_converged": {}, "notes": ["GARCH-LSTM skipped: torch is not installed"],
    }
    out = ev.evaluate(payload, "squared_return")
    fam = {m["id"]: m["family"] for m in out["models"]}
    assert fam == {"sgarch": "GARCH family", "gjr": "GARCH family", "har": "Machine learning", "lstm": "Machine learning"}
    assert out["notes"] == payload["notes"] and out["models"][0]["id"] == "gjr"
