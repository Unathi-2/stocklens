/** Colours for the volatility models, shared by the model and evaluation tabs. Machine learning models are drawn dashed. */
export const MODEL_COLORS: Record<string, string> = {
  sgarch: "#4f8ef7",
  egarch: "#e0698f",
  gjr: "#d9992b",
  figarch: "#3fb3c4",
  fgarch: "#a47be0",
  aparch: "#7fbf6a",
  har: "#2fb59a",
  ridge: "#c26d3f",
  gbm: "#8794a8",
  lstm: "#d4c13a",
  garch_lstm: "#e05a47",
};

export const DASHED_MODELS = new Set(["har", "ridge", "gbm", "lstm", "garch_lstm"]);
